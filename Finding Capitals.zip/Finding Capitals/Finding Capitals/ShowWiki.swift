//
//  ShowWiki.swift
//  Finding Capitals
//
//  Created by Tugce Tekerlekci on 7/7/16.
//  Copyright © 2016 Tugce Tekerlekci. All rights reserved.
//

import UIKit

var city:String = ""

class ShowWiki: UIViewController {



    @IBOutlet var web: UIWebView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()


    let url = NSURL(string: "https://en.wikipedia.org/wiki/" + city)!
    print(city)
    web.loadRequest(NSURLRequest(URL: url))
    
    
    
    }
    

    
    


}
