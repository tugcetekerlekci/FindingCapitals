//
//  ViewController.swift
//  Find Capitals
//
//  Created by Tugce Tekerlekci on 7/7/16.
//  Copyright © 2016 Tugce Tekerlekci. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    var countries:[String] = []
    var capitals:[String] = []
    
    @IBOutlet weak var countryLabel: UILabel!
    
    @IBOutlet weak var capitalLabel: UITextField!
    var randomNumber = Int(arc4random_uniform(10))
    
    @IBAction func answerButton(sender: AnyObject) {
        
        if capitalLabel.text! == capitals[randomNumber]
        {
            answerLabel.text = "This is correct! Try another!"
            capitalLabel.text! = ""
            
            randomNumber = Int(arc4random_uniform(10))
            countryLabel.text = countries[randomNumber]
        
        }
        
        else
        {
            answerLabel.text = "Nope! Here comes another!"
            
            capitalLabel.text! = ""

            randomNumber = Int(arc4random_uniform(10))
            countryLabel.text = countries[randomNumber]
            
            
        
        }
    
    
    }
  
    @IBOutlet weak var answerLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //use appdelegate to connect to core data
        let appDel:AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        
        let context: NSManagedObjectContext = appDel.managedObjectContext
        //handler for us to be access to core data data base.
        
        
        let cornerRadius : CGFloat = 5.0
        countryLabel.layer.borderWidth = 2.0
        countryLabel.layer.cornerRadius = cornerRadius
        countryLabel.layer.borderColor = UIColor.orangeColor().CGColor
        
        
        answerLabel.backgroundColor = UIColor.clearColor()
        answerLabel.layer.borderWidth = 2.0
        answerLabel.layer.cornerRadius = cornerRadius
        answerLabel.layer.borderColor = UIColor.orangeColor().CGColor

        
        
        
        
        
        
        
        
        //a new user for users entity

        do
        {
            try context.save()
            
        }catch
        {
            print("there is a problem")
            
        }
        
        let request = NSFetchRequest(entityName: "Information")
        
        request.returnsObjectsAsFaults = false
        request.predicate = NSPredicate(format: "capital = %@", "Batu")
        
        
        do{
            let results = try context.executeFetchRequest(request)
            //print(results)
            
            
            if results.count>0
            {
                for result in results as! [NSManagedObject]
                {
                    
                    do{
                        try context.save()
                    }
                    catch{
                        
                        
                    }
                    
                    if let country = result.valueForKey("country") as? String
                    {
                        countries.append(country)
                    }
                    
                    if let capital = result.valueForKey("capital") as? String
                    {
                        capitals.append(capital)
                        
                    }
                    
                }
                
                
            }
            
            print(capitals)
            print(countries)
           
            countryLabel.text = countries[randomNumber]
          
            
        }
            
        catch{}
   
        
    }
    
    
    
    
    
    
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
  
}

